import { Component } from "@odoo/owl";

export class WidgetAnnouncement extends Component {}

WidgetAnnouncement.template = "sp_main_menu.WidgetAnnouncement";
